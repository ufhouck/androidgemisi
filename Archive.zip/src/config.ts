// Weather API key
export const WEATHER_API_KEY = '72fc1f39f6ee44de8a874625241911';

// Location coordinates
export const LOCATIONS = {
  gumusluk: {
    lat: 37.0407,
    lon: 27.2342,
    name: 'Gümüşlük',
    aqi: 'no'
  },
  datca: {
    lat: 36.7376,
    lon: 27.6869,
    name: 'Datça',
    aqi: 'no'
  }
} as const;